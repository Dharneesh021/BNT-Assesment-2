import React, { useState } from 'react'

const List = () => {
    const [list] = useState([
        {
            id:1,
            name:"John"
        },
        {
            id:2,
            name:"Jane"
        },
        {
            id:3,
            name:"Alex"
        },
    ])
  return (
    <>
        <h1>Task-5 List the elements</h1>
        {list.map((item) => 
            <ul key={item.id}>
                <li>{item.name}</li>
            </ul>
        )}
    </>
  )
}

export default List