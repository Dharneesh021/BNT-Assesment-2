import React, { useState } from 'react'

const ResetCounter = () => {
    const [count, setCount] = useState(0)
  return (
    <>
        <h1>Task-12 Counter</h1>
    <div style={{display:"flex",gap:"10px"}}>
        <button onClick={()=> setCount(count + 1)}>+</button>
        <p>{count == 10 ? setCount(0) : count}</p>
        <button onClick={()=> setCount(count - 1)}>-</button>
    </div>
    
    </>
  )
}

export default ResetCounter