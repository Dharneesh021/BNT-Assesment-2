import React, { useState } from 'react'

const ToggleAct = () => {
    const [message, setMessage] = useState("Hello");
  return (
    <>
    <h1>Task-2 Toggle event</h1>
    <button onClick={() => setMessage(message === "Hello" ? "Welcome Back" : "Hello")}>
      Toggle Message
    </button>
    <p>{message}</p>
    </>
  )
}

export default ToggleAct