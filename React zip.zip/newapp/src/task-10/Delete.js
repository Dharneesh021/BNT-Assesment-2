import React, { useState } from 'react'

const Delete = () => {
    const [list , setList] = useState([
        {
            id: 1 ,
            name: "vijay"
        },
        {
            id: 2 ,
            name: "Arun"
        },
        {
            id: 3,
            name: "Babu"
        },
    ])

    const handleDelete = (id) =>{
        let out = list.filter((item)=> id != item.id)
        setList(out)
    }
  return (
    <div>
        <h1>Task-10 Delete Feature</h1>
        {
            list.map((item)=> 
            <ul key={item.id} style={{display:"flex", gap:"10px"}}>
                <li>{item.name}</li>
                <button onClick={()=> handleDelete(item.id)}>Delete</button>
            </ul>)
        }
    </div>
  )
}

export default Delete