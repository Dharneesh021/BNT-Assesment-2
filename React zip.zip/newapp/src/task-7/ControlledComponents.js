import  { useState } from 'react'

const ControlledComponents = () => {
    const [name, setName] = useState("");
    const handleCheck = (e) => {
        console.log(e.target.value)
        setName(e.target.value); 
    }
  return (

    <div>
        <h1>Task-7 ControlledComponents</h1>

        <form>
            <label htmlFor="name">Name:</label>
            <input 
                type="text" 
                id="name" 
                name="name"
                value={name} 
                onChange={(e) => handleCheck(e)} 
            />
        </form>
   </div>
  )
}

export default ControlledComponents