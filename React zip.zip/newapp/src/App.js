import Counter from "./task-1/Counter";
import Delete from "./task-10/Delete";
import ToDo from "./task-11/ToDo";
import ResetCounter from "./task-12/ResetCounter";
import ToggleAct from "./task-2/ToggleAct";
import Parent from "./task-3/Parent";
import GrandParent from "./task-4/GrandParent";
import List from "./task-5/List";
import CheckBox from "./task-6/CheckBox";
import ControlledComponents from "./task-7/ControlledComponents";
import DataShow from "./task-8/DataShow";
import Disable from "./task-9/Disable";



function App() {
  return (
    <>
      {/* Task 1 */}
      <Counter />

      {/* Task 2 */}
      <ToggleAct />

      {/* Task 3 */}
      <Parent />

      {/* Task 4 */}
      <GrandParent />

      {/* Task 5 */}
      <List />

      {/* Task 6 */}
      <CheckBox />

      {/* Task 7 */}
      <ControlledComponents />

      {/* Task 8 */}
      <DataShow />

      {/* Task 9 */}
      <Disable />

      {/* Task 10 */}
      <Delete />

      {/* Task 11 */}
      <ToDo />


      {/* Task 12 */}
      <ResetCounter />
    </>
  );
}

export default App;
