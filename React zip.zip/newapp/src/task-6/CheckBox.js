import { useState } from 'react'

const CheckBox = () => {
    const [para , setPara] = useState(false)
  return (
    <div>
        <h1>Task-6 CheckBox</h1>
        <label htmlFor="">CheckBox : </label>
        <input type="checkbox" name="" id="" onChange={()=> setPara(para ? false : true)} />
        {para == true ? <p>You checked the box!</p> : ""}
    </div>
  )
}

export default CheckBox