import React from 'react'
import Child2 from './Child2'

const Parent2 = ({name}) => {
  return (
    <div>
        <Child2 name={name} />
    </div>
  )
}

export default Parent2