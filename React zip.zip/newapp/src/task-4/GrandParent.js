import React from 'react'
import Parent2 from './Parent2'

const GrandParent = () => {
    const name = "Hello from GrandParent"
  return (
      <>
    <h1>Task-4 Props Drilling</h1>
    <Parent2 name = {name} />
    </>
  )
}

export default GrandParent