import React from 'react'

const Child2 = ({name}) => {
  return (
    <div>
      <h2>{name}</h2>
    </div>
  )
}

export default Child2