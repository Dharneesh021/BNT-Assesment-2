import React, { useState } from 'react'

const Counter = () => {

    const [count, setCount] = useState(0)

  return (
    <>
    <h1>Task-1 Counter</h1>
    <div style={{display:"flex",gap:"10px"}}>
        <button onClick={()=> setCount(count + 1)}>+</button>
        <p>{count}</p>
        <button onClick={()=> setCount(count - 1)}>-</button>
    </div>
    
    </>
  )
}

export default Counter