import React, { useState } from 'react'
import InputComp from './InputComp'

const DataShow = () => {
    const [par , setPar] = useState("")
    const label = "Name : "
    const placeholder = "Enter Your name"
    const name = "Username"

    const handleChange = (e) => {
        setPar(e.target.value)
    }
  return (
    <div>
      <h1>Task-8 Props Sharing to input feild</h1>
      <InputComp
        label={label}
        placeholder={placeholder}
        name={name}
        handleChange={handleChange}
      />
      <p>{par}</p>
    </div>
  );
}

export default DataShow