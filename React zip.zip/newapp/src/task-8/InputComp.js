import React from 'react'

const InputComp = ({label,placeholder,name,handleChange}) => {
  return (
    <div>
        <form>
            <label htmlFor={name}>{label}</label>
            <input type="text"  placeholder={placeholder} name={name} onChange={(e)=> handleChange(e)}/>
        </form>
    </div>
  )
}

export default InputComp