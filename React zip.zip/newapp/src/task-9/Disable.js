import { useState } from 'react'

const Disable = () => {
    const [name , setName] = useState("")
    const [password , setPassword] = useState("")
  return (
    <div>
        <h1>Task-9 Disable the submit button</h1>
        <form>
            {/* Name */}
            <label htmlFor="name">Name : </label>
            <input type="text" name='name' id='name' placeholder='Enter the name' onChange={(e) => setName(e.target.value)}/>

            {/* Password */}
            <label htmlFor="password">Password : </label>
            <input type="password" name='password' id='password' placeholder='Enter the password'onChange={(e) => setPassword(e.target.value)}/>
<br /><br />
            <button disabled={name.length === 0 || password.length === 0} style={{marginLeft:"30px"}}>Submit</button>
        </form>
    </div>
  )
}

export default Disable