import React, { useState } from 'react'

const ToDo = () => {
    const [newList , setNewList] = useState("")
  const [list, setList] = useState([
    {
      id: 1,
      name: "vijay",
    },
    {
      id: 2,
      name: "Arun",
    },
    {
      id: 3,
      name: "Babu",
    },
  ]);

  const handleDelete = (id) => {
    let out = list.filter((item) => id != item.id);
    setList(out);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newList) {
      setList([...list, { id: list.length + 1, name: newList }]);
      setNewList("");
    }
  };
  return (
    <div>
      <h1>Task-11 ToDo List</h1>
      <input type="text" value={newList} onChange={(e) => setNewList(e.target.value)} />
      <button onClick={handleSubmit}>Submit</button>

       {
            list.map((item)=> 
            <ul key={item.id} style={{display:"flex", gap:"10px"}}>
                <li>{item.name}</li>
                <button onClick={()=> handleDelete(item.id)}>Delete</button>
            </ul>)
        }
    </div>
  );
};

export default ToDo