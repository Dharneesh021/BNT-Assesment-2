import Child from "./Child"


const Parent = () => {
    const name = "Parent to Child Component";
  return (
    <>
    <h1>Task-3 Parent to child</h1>
    <Child name={name}/>
    </>
  )
}

export default Parent